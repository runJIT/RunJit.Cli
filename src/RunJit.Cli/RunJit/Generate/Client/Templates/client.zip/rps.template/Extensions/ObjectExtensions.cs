﻿using System;
using System.Diagnostics.CodeAnalysis;

namespace rps.template
{
    internal static class ObjectExtensions
    {
        internal static bool IsNotNull([NotNullWhen(true)] this object? source)
        {
            return source is not null;
        }

        internal static bool IsNull([NotNullWhen(false)] this object? source)
        {
            return source is null;
        }

        public static T Cast<T>(this object source)
        {
            return (T)source;
        }
    }

    internal static class GenericTypeExtensions
    {
        internal static int ToInt<T>(this T value)
            where T : struct, IComparable, IFormattable, IConvertible
        {
            return value.ToIntOrDefault(0);
        }

        internal static int ToInt<T>(this T? value)
            where T : struct, IComparable, IFormattable, IConvertible
        {
            return value.ToIntOrDefault(0);
        }

        internal static int ToIntOrDefault<T>(this T? value,
                                              int defaultValue)
            where T : struct, IComparable, IFormattable, IConvertible
        {
            if (value == null)
            {
                return defaultValue;
            }

            if (value is int intValue)
            {
                return intValue;
            }

            return defaultValue;
        }

        internal static int ToIntOrDefault<T>(this T value,
                                              int defaultValue)
            where T : struct, IComparable, IFormattable, IConvertible
        {

            if (value is int intValue)
            {
                return intValue;
            }

            return defaultValue;
        }
    }
}
