﻿using System;
using System.Collections.Generic;
using System.Collections.Immutable;
using System.Linq;
using Extensions.Pack;
using Microsoft.AspNetCore.Mvc;
using Microsoft.CodeAnalysis.CSharp.Syntax;
using Solution.Parser.CSharp;
using CSharpSyntaxTree = Microsoft.CodeAnalysis.CSharp.CSharpSyntaxTree;

namespace RunJIT.CodeRules.Api
{
    [TestClass]
    public class MinimalApiTestBase : MsTestBase
    {
        public MinimalApiTestBase()
        {
            // Without context statements like in program.cs or startup.cs
            EndpointInfos = GetAllEndpoints().ToImmutableList();
            AllApiVersions = EndpointInfos.Select(e => e.MapToApiVersion).Where(v => v.IsNotNull()).Distinct().Select(v => new ApiVersion(v!.Value, 0)).ToImmutableList();

            static IEnumerable<EndpointInfo> GetAllEndpoints()
            {
                var endpointParser = new EndpointParser();

                foreach (var syntaxTree in ProductiveSyntaxTrees)
                {
                    foreach (var syntaxTreeClass in syntaxTree.Classes)
                    {
                        // We only interested in extensions methods
                        if (syntaxTreeClass.Modifiers.Contains(Modifier.Static).IsFalse())
                        {
                            continue;
                        }

                        // Endpoint registrations does not have IServiceCollection
                        if (syntaxTreeClass.SyntaxTree.Contains("IServiceCollection"))
                        {
                            continue;
                        }

                        // We only interested in endpoint builder extensions
                        if (syntaxTreeClass.SyntaxTree.Contains("IEndpointRouteBuilder").IsFalse())
                        {
                            continue;
                        }

                        var endpoint = endpointParser.Parse(syntaxTreeClass.SyntaxTree, syntaxTree.FileName);

                        if (endpoint.IsNull())
                        {
                            continue;
                        }

                        yield return endpoint;
                    }
                }
            }
        }

        public static IImmutableList<EndpointInfo> EndpointInfos { get; set; } = ImmutableList<EndpointInfo>.Empty;

        public static IImmutableList<ApiVersion> AllApiVersions { get; set; } = ImmutableList<ApiVersion>.Empty;
    }

    public record EndpointInfo
    {
        public string HttpMethod { get; init; } = string.Empty;

        public string EndpointHandlerName { get; init; } = string.Empty;

        public ImmutableList<ProducesInfo> Produces { get; init; } = ImmutableList<ProducesInfo>.Empty;

        public ImmutableList<string> WithTags { get; init; } = ImmutableList<string>.Empty;

        public string WithName { get; init; } = string.Empty;

        public int? MapToApiVersion { get; init; }

        public string WithDescriptionFromFile { get; init; } = string.Empty;

        public string WithDescription { get; init; } = string.Empty;

        public string WithSummaryFromFile { get; init; } = string.Empty;

        public string WithSummary { get; init; } = string.Empty;

        public string SyntaxTree { get; init; } = string.Empty;

        public string FilePath { get; init; } = string.Empty;
    }

    public record ProducesInfo
    {
        public string Type { get; init; } = string.Empty;

        public int? HttpStatusCode { get; init; } // .Produces<ProblemDetails>(401)

        public string HttpStatusCodeName { get; init; } = string.Empty; // .Produces<ProblemDetails>(StatusCodes.Status401Unauthorized)

        public string SyntaxTree { get; init; } = string.Empty;
    }

    public class EndpointParser
    {
        private static readonly string[] MapActions =
        {
            "MapGet", "MapPost", "MapDelete",
            "MapPut", "MapPatch"
        };

        public EndpointInfo? Parse(string code,
                                   string filePath)
        {
            var tree = CSharpSyntaxTree.ParseText(code);
            var root = tree.GetRoot();

            // Find all invocation expressions
            var invocationExpressionSyntaxes = root.DescendantNodes().OfType<InvocationExpressionSyntax>().ToList();

            var mapMethod = invocationExpressionSyntaxes.FirstOrDefault(invocation =>
                                                                            invocation.Expression is MemberAccessExpressionSyntax memberAccess &&
                                                                            MapActions.Any(m => memberAccess.Name.Identifier.Text.StartsWith(m, StringComparison.OrdinalIgnoreCase)));

            if (mapMethod == null)
            {
                return null;
            }

            // Extract HTTP method (e.g., "DELETE" from MapDelete)
            var httpMethod = (mapMethod.Expression as MemberAccessExpressionSyntax)?.Name.Identifier.Text.Replace("Map", "").ToUpperInvariant();

            // Extract the handler name (e.g., "HandleAsync")
            var handlerArgument = mapMethod.ArgumentList.Arguments.LastOrDefault();
            var handlerName = handlerArgument?.Expression.ToString() ?? "UnknownHandler";

            // Properly extract chained method calls
            var methodCalls = ExtractChainedMethodCalls(invocationExpressionSyntaxes.First());

            // Extract Produces<T>(code)
            // Works only for the generic usage !
            var producesList = methodCalls
                               .Where(m => m.Expression is MemberAccessExpressionSyntax member &&
                                           member.Name is GenericNameSyntax)
                               .Select(m =>
                                       {
                                           var member = (MemberAccessExpressionSyntax)m.Expression;
                                           var genericName = (GenericNameSyntax)member.Name; // Extracting GenericNameSyntax for Produces<T>

                                           var typeArg = genericName.TypeArgumentList.Arguments.FirstOrDefault()?.ToString() ?? "UnknownType";
                                           var statusCodeArgSyntax = m.ArgumentList.Arguments.FirstOrDefault()?.Expression;

                                           int? statusCode = null;
                                           var statusCodeName = string.Empty;

                                           if (statusCodeArgSyntax is LiteralExpressionSyntax literal) // Handles .Produces<ProblemDetails>(401)
                                           {
                                               if (int.TryParse(literal.Token.ValueText, out var statusCodeNumber))
                                               {
                                                   statusCode = statusCodeNumber;
                                               }
                                           }
                                           else if (statusCodeArgSyntax is MemberAccessExpressionSyntax memberAccess) // Handles .Produces<ProblemDetails>(StatusCodes.Status401Unauthorized)
                                           {
                                               statusCodeName = memberAccess.ToString();
                                           }

                                           // .Produces<CreateProjectResponse>()  = .Produces<CreateProjectResponse>(StatusCodes.Status200OK)
                                           else
                                           {
                                               statusCode = 200;
                                               statusCodeName = "StatusCodes.Status200OK";
                                           }

                                           var syntaxTree = $"{genericName}({(statusCodeName.IsNullOrWhiteSpace() ? statusCode.ToString() : statusCodeName)})";

                                           return new ProducesInfo
                                                  {
                                                      Type = typeArg,
                                                      HttpStatusCode = statusCode,
                                                      HttpStatusCodeName = statusCodeName,
                                                      SyntaxTree = syntaxTree
                                                  };
                                       })
                               .ToImmutableList();

            // Extract WithTags("Projects")
            var withTags = methodCalls.Where(m => m.Expression is MemberAccessExpressionSyntax member &&
                                                  member.Name.Identifier.Text == "WithTags")
                                      .SelectMany(m => m.ArgumentList.Arguments)
                                      .Select(arg => arg.Expression.ToString().Trim('"'))
                                      .ToImmutableList();

            // Extract WithName("deleteAllProjectsV1")
            var withName = GetEndpointMetaInfo(methodCalls, "WithName");

            // Extract MapToApiVersion(1)
            var apiVersion = methodCalls.Where(m => m.Expression is MemberAccessExpressionSyntax member &&
                                                    member.Name.Identifier.Text == "MapToApiVersion")
                                        .Select(m => m.ArgumentList.Arguments.FirstOrDefault()?.Expression.ToString())
                                        .Select(arg =>
                                                {
                                                    if(int.TryParse(arg, out var v))
                                                    {
                                                        return (int?)v;
                                                    }

                                                    return null;
                                                })
                                        .FirstOrDefault();

            // Extract WithDescriptionFromFile("Description.txt")
            var descriptionFile = GetEndpointMetaInfo(methodCalls, "WithDescriptionFromFile");

            // Extract WithDescriptionFromFile("Description.txt")
            var description = GetEndpointMetaInfo(methodCalls, "WithDescription");

            // Extract WithSummaryFromFile("Summary.txt")
            var summaryFile = GetEndpointMetaInfo(methodCalls, "WithSummaryFromFile");

            // Extract WithSummaryFromFile("Summary.txt")
            var summary = GetEndpointMetaInfo(methodCalls, "WithSummary");

            return new EndpointInfo
                   {
                       HttpMethod = httpMethod ?? string.Empty,
                       EndpointHandlerName = handlerName,
                       Produces = producesList,
                       WithTags = withTags,
                       WithName = withName ?? string.Empty,
                       MapToApiVersion = apiVersion,
                       WithDescriptionFromFile = descriptionFile ?? string.Empty,
                       WithDescription = description ?? string.Empty,
                       WithSummaryFromFile = summaryFile ?? string.Empty,
                       WithSummary = summary ?? string.Empty,
                       SyntaxTree = code,
                       FilePath = filePath
                   };
        }

        private string? GetEndpointMetaInfo(List<InvocationExpressionSyntax> invocationExpressionSyntaxes,
                                            string name)
        {
            var metaInfo = invocationExpressionSyntaxes.Where(m => m.Expression is MemberAccessExpressionSyntax member &&
                                                                   member.Name.Identifier.Text == name)
                                                       .Select(m => m.ArgumentList.Arguments.FirstOrDefault()?.Expression.ToString().Trim('"'))
                                                       .FirstOrDefault();

            return metaInfo;
        }

        /// <summary>
        ///     Recursively extracts all method calls chained to the original MapXXX method.
        /// </summary>
        private static List<InvocationExpressionSyntax> ExtractChainedMethodCalls(InvocationExpressionSyntax rootMethod)
        {
            var methods = new List<InvocationExpressionSyntax>();
            var current = rootMethod;

            while (current is InvocationExpressionSyntax invocation)
            {
                methods.Add(invocation);

                if (invocation.Expression is MemberAccessExpressionSyntax memberAccess &&
                    memberAccess.Expression is InvocationExpressionSyntax innerInvocation)
                {
                    current = innerInvocation;
                }
                else
                {
                    break;
                }
            }

            return methods;
        }
    }
}
