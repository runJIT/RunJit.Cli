﻿using System.Collections.Immutable;
using Extensions.Pack;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace RunJIT.CodeRules
{
    [TestCategory("CodeRules")]
    [TestCategory("CodeRules Jsons")]
    [TestClass]
    public class RJIT_CR_J_00001 : MsTestBase
    {
        /*
         * RJIT_CR_J_00001 - Ensures that Json files are not only one line, so it is easier to read and maintain.
         */
        [DataTestMethod]
        public void Ensure_Json_Is_Not_Only_One_Line()
        {
            var badFormattedJsonsErrorInfo = (from jsonFile in JsonFiles
                                              where jsonFile.FileInfo.FullName.DoesNotContain(".Cli.") && // Cli have special options for 1 line jsons for postprocessing
                                                    IsValidJson(jsonFile.Content) &&
                                                    jsonFile.ContentAsLines.Length <= 1 &&
                                                    jsonFile.Content.Length > 2 // Exception case imagine [] or {}
                                              select new
                                              {
                                                  Error = $@"
Json is not properly formatted: '{jsonFile.FileInfo.Name}'.
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
Json File:    {jsonFile.FileInfo.Name}
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
Content:
{jsonFile.Content}
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
Sample:
{FormatJson(jsonFile.Content)}
"
                                              }).ToImmutableList();

            Assert.IsTrue(badFormattedJsonsErrorInfo.IsEmpty(),
                          @$"
Documentation: {DocumentationDomain}#RJIT_CR_J_00001

Jsons files are not correctly formatted. Please check the files:{Environment.NewLine}{badFormattedJsonsErrorInfo.Select(e => e.Error).Flatten(Environment.NewLine)}");
        }

        public static bool IsValidJson(string jsonContent)
        {
            try
            {
                JToken.Parse(jsonContent);

                return true;
            }
            catch (JsonReaderException)
            {
                return false;
            }
        }

        public string FormatJson(string jsonContent)
        {
            try
            {
                var jsonObject = JObject.Parse(jsonContent);
                var formattedJson = JsonConvert.SerializeObject(jsonObject, Formatting.Indented);

                return formattedJson;
            }
            catch (JsonException ex)
            {
                return $"Cannot be automatically formated: {ex.Message}";
            }
        }
    }
}
