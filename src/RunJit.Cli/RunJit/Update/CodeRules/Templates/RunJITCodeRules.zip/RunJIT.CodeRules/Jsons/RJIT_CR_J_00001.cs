﻿
using System;
using System.Collections.Immutable;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Xml.Linq;
using ConsoleTables;
using Extensions.Pack;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace RunJIT.CodeRules
{
    [TestCategory("Coding-Rules")]
    [TestCategory("Jsons")]
    [TestClass]
   public class RJIT_CR_J_00001 : MsTestBase
   {
       /*
        * RJIT_CR_J_00001 - Ensures that Json files are not only one line, so it is easier to read and maintain.
        */
       [DataTestMethod]
       public void Ensure_Json_Is_Not_Only_One_Line()
       {
           var requestJsons = (from jsons in JsonFiles select jsons).Distinct().ToImmutableList();
           
           var badFormattedJsons = (from json in requestJsons
               where IsValidJson(json.Content) && IsSingleLineJson(json.Content)
               select json).ToImmutableList();
           
           var badFormattedJsonsErrorInfo = (from badFormattedJson in badFormattedJsons
               select new
               {
                   Error = $@"
Json is not properly formatted: '{badFormattedJson.FileInfo.Name}'.
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
Json File:    {badFormattedJson.FileInfo.Name}
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
Content:
{badFormattedJson.Content}
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
Sample:
{FormatJson(badFormattedJson.Content)}
"
               }).ToImmutableList();

           
           Assert.IsTrue(badFormattedJsonsErrorInfo.IsEmpty(),
               @$"
Documentation: {DocumentationDomain}#RJIT_CR_J_00001

Jsons files are not correctly formatted. Please check the files:{Environment.NewLine}{badFormattedJsonsErrorInfo.Select(e => e.Error).Flatten(Environment.NewLine)}");
           
       }
   
       public static bool IsValidJson(string jsonContent)
        {
            try
            {
                JToken.Parse(jsonContent);
                return true;
            }
            catch (JsonReaderException)
            {
                return false;
            }
        }
   
       public static bool IsSingleLineJson(string jsonContent)
       {
           return !jsonContent.Contains('\n') && !jsonContent.Contains('\r');
       }
       
       public string FormatJson(string jsonContent)
       {
           try
           { 
               var jsonObject = JObject.Parse(jsonContent); 
               var formattedJson = JsonConvert.SerializeObject(jsonObject, Formatting.Indented); 
               return formattedJson;
           }
           catch (JsonException ex)
           {
              return $"Cannot be automatically formated: {ex.Message}";
           }
           
       }
   }
}
