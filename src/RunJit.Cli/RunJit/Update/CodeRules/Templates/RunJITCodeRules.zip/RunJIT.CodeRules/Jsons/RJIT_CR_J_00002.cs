﻿using System;
using System.Collections.Immutable;
using System.Linq;
using Extensions.Pack;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace RunJIT.CodeRules
{
    [TestCategory("CodeRules")]
    [TestCategory("CodeRules Jsons")]
    [TestClass]
    public class RJIT_CR_J_00002 : MsTestBase
    {
        /*
         * RJIT_CR_J_00002 - Ensure Json is valid, so it doesn't cause any issues in the future, also does not takes
         * into consideration format, but functionality.
         */
        [DataTestMethod]
        public void Ensure_Json_Is_Valid()
        {
            var requestJsons = (from jsons in JsonFiles select jsons).Distinct().ToImmutableList();

            var badFormattedJsons = (from json in requestJsons
                                     where !IsValidJson(json.Content)
                                     select json).ToImmutableList();

            var badFormattedJsonsErrorInfo = (from badFormattedJson in badFormattedJsons
                                              select new
                                                     {
                                                         Error = $@"
Json is not properly formatted: '{badFormattedJson.FileInfo.Name}'.
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
Json File:    {badFormattedJson.FileInfo.Name}
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
Content:
{badFormattedJson.Content}
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
Error:
{FormatJson(badFormattedJson.Content)}
"
                                                     }).ToImmutableList();

            Assert.IsTrue(badFormattedJsonsErrorInfo.IsEmpty(),
                          @$"
Documentation: {DocumentationDomain}#RJIT_CR_J_00002

Jsons files are not valid. Please check the files:{Environment.NewLine}{badFormattedJsonsErrorInfo.Select(e => e.Error).Flatten(Environment.NewLine)}");
        }

        public static bool IsValidJson(string jsonContent)
        {
            if (jsonContent.Contains('\''))
            {
                return false;
            }

            if (jsonContent.Trim().EndsWith(",}", StringComparison.Ordinal))
            {
                return false;
            }

            try
            {
                JToken.Parse(jsonContent);

                return true;
            }
            catch (JsonReaderException)
            {
                return false;
            }
        }

        public string FormatJson(string jsonContent)
        {
            if (jsonContent.Contains('\''))
            {
                return "Invalid Json file: Single quotes are not allowed in Json files.";
            }

            if (jsonContent.Trim().EndsWith(",}", StringComparison.Ordinal))
            {
                return "Invalid Json file: Json file should not end with a comma.";
            }

            try
            {
                var jsonObject = JObject.Parse(jsonContent);
                var formattedJson = JsonConvert.SerializeObject(jsonObject, Formatting.Indented);

                return formattedJson;
            }
            catch (JsonException ex)
            {
                return $"Invalid Json file: {ex.Message}";
            }
        }
    }
}
