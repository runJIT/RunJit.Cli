﻿using System.Collections.Immutable;
using Extensions.Pack;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace RunJIT.CodeRules
{
    [TestCategory("CodeRules")]
    [TestCategory("CodeRules Jsons")]
    [TestClass]
    public class RJIT_CR_J_00002 : MsTestBase
    {
        /*
         * RJIT_CR_J_00002 - Ensure Json is valid, so it doesn't cause any issues in the future, also does not takes
         * into consideration format, but functionality.
         */
        [DataTestMethod]
        public void Ensure_Json_Is_Valid()
        {
            var badFormattedJsons = (from json in JsonFiles
                                     where !IsValidJson(json.Content)
                                     select new
                                     {
                                         Error = $@"
Json is not properly formatted: '{json.FileInfo.Name}'.
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
Json File:    {json.FileInfo.Name}
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
Content:
{json.Content}
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
Error:
{FormatJson(json.Content)}
"
                                     }).ToImmutableList();

            Assert.IsTrue(badFormattedJsons.IsEmpty(),
                          @$"
Documentation: {DocumentationDomain}#RJIT_CR_J_00002

Jsons files are not valid. Please check the files:{Environment.NewLine}{badFormattedJsons.Select(e => e.Error).Flatten(Environment.NewLine)}");
        }

        public static bool IsValidJson(string jsonContent)
        {
            if (jsonContent.Contains("':'"))
            {
                return false;
            }

            if (jsonContent.Trim().EndsWith(",}", StringComparison.Ordinal))
            {
                return false;
            }

            try
            {
                JToken.Parse(jsonContent);

                return true;
            }
            catch (JsonReaderException)
            {
                return false;
            }
        }

        public string FormatJson(string jsonContent)
        {
            if (jsonContent.Contains('\''))
            {
                return "Invalid Json file: Single quotes are not allowed in Json files.";
            }

            if (jsonContent.Trim().EndsWith(",}", StringComparison.Ordinal))
            {
                return "Invalid Json file: Json file should not end with a comma.";
            }

            try
            {
                var jsonObject = JObject.Parse(jsonContent);
                var formattedJson = JsonConvert.SerializeObject(jsonObject, Formatting.Indented);

                return formattedJson;
            }
            catch (JsonException ex)
            {
                return $"Invalid Json file: {ex.Message}";
            }
        }
    }
}
