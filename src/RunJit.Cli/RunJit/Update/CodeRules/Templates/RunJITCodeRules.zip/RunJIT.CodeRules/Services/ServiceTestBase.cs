using System.Collections.Immutable;
using Extensions.Pack;
using Microsoft.Extensions.DependencyInjection;
using Solution.Parser.CSharp;

namespace RunJIT.CodeRules
{
    [TestClass]
    public class ServiceTestBase : MsTestBase
    {
        private readonly string[] _servicesWhichNeedsNoRegistrationExtension = ["IOpenApiDocumentTransformer"];

        public ServiceTestBase()
        {
            Services = FindServices().ToImmutableList();

            IEnumerable<(Class Class, Class? Registration, CSharpSyntaxTree syntaxTree, Class? WrongNameRegistration)> FindServices()
            {
                foreach (var cSharpSyntaxTree in ProductiveSyntaxTrees)
                {
                    var services = cSharpSyntaxTree.Classes.Where(@class => @class.Modifiers.Any(m => m is Modifier.Static or Modifier.Abstract).IsFalse() &&
                                                                            MediatorTestBase.HandlerInterfaces.Any(type => @class.BaseTypes.Any(t => t.TypeName.StartWith(type))).IsFalse() &&
                                                                            @class.Methods.Any() &&
                                                                            (@class.BaseTypes.IsEmpty() || @class.BaseTypes.Any(t => t.TypeName.StartWith("I")))).ToImmutableList();

                    foreach (var service in services)
                    {
                        var fileInfo = new FileInfo(service.FilePath);

                        if (fileInfo.Directory!.Name.Contains("startup", StringComparison.OrdinalIgnoreCase))
                        {
                            continue;
                        }

                        if (service.BaseTypes.Any(b => _servicesWhichNeedsNoRegistrationExtension.Contains(b.TypeName)))
                        {
                            continue;
                        }

                        if (service.Interfaces.Any(b => _servicesWhichNeedsNoRegistrationExtension.Contains(b.Name)))
                        {
                            continue;
                        }

                        // if class will be instantiated with new then we can ignore it
                        var newExpressions = Classes.Where(@class =>
                                                           {
                                                               // private Service myService = new Service();
                                                               if (@class.SyntaxTree.Contains($"new {service.Name}"))
                                                               {
                                                                   return true;
                                                               }

                                                               // private Service myService = new();
                                                               if (@class.SyntaxTree.Split(Environment.NewLine).Any(line => line.Contains(service.Name) &&
                                                                                                                            line.Contains(" = new")))
                                                               {
                                                                   return true;
                                                               }

                                                               return false;
                                                           }).ToImmutableList();

                        if (newExpressions.Any())
                        {
                            continue;
                        }

                        var registrationClass = cSharpSyntaxTree.Classes.FirstOrDefault(@class => @class.Name.Contains(service.Name) && @class.Name.Contains("Extension"));

                        var wrongNameRegistration = (from @class in cSharpSyntaxTree.Classes
                                                     from method in @class.Methods
                                                     where method.Parameters.Any(p => p.Type == nameof(IServiceCollection)) &&
                                                           (method.MethodBody.Contains($"<{service.Name}", StringComparison.OrdinalIgnoreCase) || method.MethodBody.Contains($"{service.Name}>", StringComparison.OrdinalIgnoreCase))
                                                     select @class).FirstOrDefault();

                        yield return (service, registrationClass, cSharpSyntaxTree, wrongNameRegistration);
                    }
                }
            }
        }

        protected ImmutableList<(Class Class, Class? Registration, CSharpSyntaxTree syntaxTree, Class? WrongNameRegistration)> Services { get; private set; }
    }
}
