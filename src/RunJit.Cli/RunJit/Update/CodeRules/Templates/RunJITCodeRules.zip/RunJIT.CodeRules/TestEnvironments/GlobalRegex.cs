﻿using System.Text.RegularExpressions;

namespace RunJIT.CodeRules
{
    internal static partial class GlobalRegex
    {
        [GeneratedRegex("([V])\\d")]
        internal static partial Regex VersionRegex();

        [GeneratedRegex(@"<([^>]*)>")]
        internal static partial Regex GetGenericTypeRegex();

        [GeneratedRegex(@"\.MapToApiVersion\((?<version>\d+)\)")]
        internal static partial Regex MapToApiVersionRegex();

        [GeneratedRegex(@"\.HasApiVersion\(new ApiVersion\((?<version>[^\)]+)\)\)")]
        internal static partial Regex HasVersionRegex();

        [GeneratedRegex(@"<([^>]*)>")]
        internal static partial Regex GenericTypeRegex();

        [GeneratedRegex(@"<(.*)>")]
        internal static partial Regex SimpleGenericTypeRegex();

        [GeneratedRegex(@"(?<=\<)(.*?)(?=\>)")]
        internal static partial Regex ReturnTypeRegex();

        [GeneratedRegex("(?<=\\{)(.*?)(?=\\})")]
        internal static partial Regex UrlParameterRegex();

        [GeneratedRegex("\\{.*?\\}")]
        internal static partial Regex ParameterRegex();

        [GeneratedRegex(@"\.Map\s*(?!Api)", RegexOptions.Singleline)]
        internal static partial Regex MapApiRegex();
    }
}
